---Install the dependencies to use the local version

npm install

---Compile

gulp build

--Watch for changes

gulp watch