
$( "p" ).click(function() {
  $( "p" ).fadeOut( "slow", function() {
    // Animation complete.
  });
});