
$( "p" ).click(function() {
  $( "p" ).fadeOut( "slow", function() {
    // Animation complete.
  });
});

	
$( "li" ).first().css( "font-size", "30px" );

$( "li" ).last().css( "color", "green" );

$("button").click(function(){
	$("img").attr("width", "1000");
});

$( "header" ).dblclick(function() {
  alert( "Hey! Stop Clicking Here!" );
});