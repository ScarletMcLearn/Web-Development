if (jQuery) {
	
	alert("We are good to go!");
	
} else {
	
	alert("Error jQuery not found!");
	
}