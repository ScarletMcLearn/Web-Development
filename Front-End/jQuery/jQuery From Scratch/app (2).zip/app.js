
$( "p" ).click(function() {
  $( "p" ).fadeOut( "slow", function() {
    // Animation complete.
  });
});

	
$( "li" ).first().css( "font-size", "30px" );

$( "li" ).last().css( "color", "green" );