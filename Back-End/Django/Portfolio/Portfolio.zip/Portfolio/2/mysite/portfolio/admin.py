from django.contrib import admin

# Register your models here.
from .models import *

# admin.site.register(Skill)

class SkillInline(admin.TabularInline):
    model = Skill

@admin.register(SkillGroup)
class SkillGroupAdmin(admin.ModelAdmin):
    # list_display = ('title', 'author', 'display_genre')
    inlines = [SkillInline]


class CommentInline(admin.TabularInline):
    model = Comment

class ImageInline(admin.TabularInline):
    model = Image

@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    # list_display = ('title', 'author', 'display_genre')
    inlines = [CommentInline, ImageInline]


admin.site.register(Image)
admin.site.register(Comment)
admin.site.register(Skill)
admin.site.register(Job)
admin.site.register(Education) 
admin.site.register(ContactQuery)