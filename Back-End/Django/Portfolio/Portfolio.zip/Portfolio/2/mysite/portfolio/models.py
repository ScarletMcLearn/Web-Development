from django.db import models

# Create your models here.
from tinymce.models import HTMLField
from taggit.managers import TaggableManager

from django.contrib.auth.models import User

from django_countries.fields import CountryField




class Skill(models.Model):

    

    skill_name = models.CharField("Skill", max_length=100, null=True, blank=True)
  
    service = models.ForeignKey('SkillGroup', on_delete=models.CASCADE, null=True, blank=True, related_name='skills')

    years = models.FloatField('Years', null=True, blank=True)

    skill_percentage = models.IntegerField(null=True, blank=True)

    def __str__(self):
        return self.skill_name
    

class SkillGroup(models.Model):

    # skill_group_type = models.CharField("Skill Group Type", max_length=50, null=True, blank=True)

    LAYERS = "icon-layers"
    GEARS = "icon-gears"
    CODE = "icon-code"

    SKILLS_GROUP_ICON_CHOICE = (
        (LAYERS, 'Tiles'),
        (GEARS, 'Gears'),
        (CODE, 'Braces')
    )

    skill_icon = models.CharField(
        max_length=50,
        choices=SKILLS_GROUP_ICON_CHOICE,
        default=LAYERS,
    )

    category = models.CharField("Skill Category", max_length=50, null=True, blank=True)

    def __str__(self):
        return self.category





class Post(models.Model):

    title = models.CharField('Post title', max_length=150, null=True, blank=True)

    body = HTMLField()

    tags = TaggableManager()

    author = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='posts')

    publish_status = models.BooleanField('Publish', default=False)

    created_on = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    updated_on = models.DateTimeField(auto_now=True, null=True, blank=True)

    # class Meta:
    #     verbose_name = _("")
    #     verbose_name_plural = _("s")

    def __str__(self):
        return self.title

    # def get_absolute_url(self):
    #     return reverse("_detail", kwargs={"pk": self.pk})


class Image(models.Model):
    post = models.ForeignKey(Post, on_delete=models.SET_NULL, related_name='images', null=True, blank=True)
    file = models.ImageField(upload_to='images', null=True, blank=True)
    position = models.PositiveSmallIntegerField(default=0)

    

    class Meta:
        ordering = ['position']

    def __str__(self):
        return '%s - %s ' % (self.post, self.file)


class Comment(models.Model):
    text = models.TextField('Comment text')

    commenter = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='comments')

    post = models.ForeignKey('Post', on_delete=models.CASCADE, related_name='comments', null=True, blank=True)

    created_on = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    updated_on = models.DateTimeField(auto_now=True, null=True, blank=True)

    def __str__(self):
        return self.text + ' - ' + self.commenter.username



class Job(models.Model):
    title = models.CharField('Job title', max_length=150, null=True, blank=True)

    start_date = models.DateField("Starting date", null=True, blank=True)

    end_date = models.DateField("Finishing date", null=True, blank=True)

    job_continuing = models.BooleanField("Job continuing", null=True, blank=True, default=False)

    company = models.CharField('Company', max_length=150, null=True, blank=True)

    company_url = models.URLField(max_length=200, null=True, blank=True)

    city = models.CharField('City', max_length=150, null=True, blank=True)

    country = CountryField(blank_label='(select country)', null=True, blank=True)

    def __str__(self):
        return self.title


class Education(models.Model):
    title = models.CharField('Education title', max_length=150, null=True, blank=True)

    institution = models.CharField('Name of institution', max_length=150, null=True, blank=True)

    institution_url = models.URLField(max_length=200, null=True, blank=True)

    start_date = models.DateField("Starting date", null=True, blank=True)

    end_date = models.DateField("Finishing date", null=True, blank=True)

    education_continuing = models.BooleanField("Education continuing", null=True, blank=True, default=False)

    city = models.CharField('City', max_length=150, null=True, blank=True)

    country = CountryField(blank_label='(select country)', null=True, blank=True)

    def __str__(self):
        return self.title


class ContactQuery(models.Model):
    name = models.CharField("Your name", max_length=150, null=True, blank=True)

    email = models.EmailField('Your email', max_length=100, null=True, blank=True)

    subject = models.CharField("Subject", max_length=200, null=True, blank=True)

    message = HTMLField(null=True, blank=True)