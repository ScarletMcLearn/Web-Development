from django import forms 

from .models import ContactQuery

class ContactForm(forms.ModelForm):
    # name = forms.CharField()

    # email = forms.EmailField()

    # subject = forms.CharField()

    # message = HTMLField()

     class Meta:
        model = ContactQuery

        exclude = ('', )