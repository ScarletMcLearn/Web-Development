from django.shortcuts import render

# Create your views here.
from django.views.generic.base import TemplateView

from django.views.generic import ListView

from .models import *

owner_pic = 'ProfilePhoto.jpg'


from .forms import ContactForm

from django.shortcuts import get_object_or_404


class HomePage(TemplateView):
    """
    Because our needs are so simple, all we have to do is
    assign one value; template_name. The home.html file will be created
    in the next lesson.
    """
    template_name = 'portfolio/services.html'

    skill_group = SkillGroup.objects.all()

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super().get_context_data(**kwargs)
        context['message'] = 'Hello world!'

        context['skill_group'] = self.skill_group

        context['owner_pic'] = owner_pic

        context['tite'] = 'Home Page'

        context['user'] = 'Beckham Muff'
        context['user_url'] = '/index'

        context['title'] = 'What i do'
        context['section_heading'] = 'My services'

        context['icon'] = 'icon-layers'   # icon-gears   # icon-code
        context['related_skill_1'] = 'Product Strategy'
        context['related_skill_2'] = 'Design Sprints'
        context['related_skill_3'] = 'UX Strategy'

        context['twitter'] = 'twitter.com/ScarletMcLearn'
        context['facebook'] = 'fb.com/ScarletMcLearn'
        context['instagram'] = 'instagram.com/ScarletMcLearn'

        context['footer_heading'] = 'Contact Us'
        context['footer_email'] = 'MailRatulNow@gmail.com'

        
        context['h_active'] = True

        return context


class AboutPageView(TemplateView):
    template_name = 'portfolio/about.html'


    skills = Skill.objects.all()

    education = Education.objects.all()

    jobs = Job.objects.all()

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        context['skills'] = self.skills

        context['education'] = self.education

        context['jobs'] = self.jobs


        context['message'] = 'Hello world!'

        context['owner_pic'] = owner_pic

        context['user'] = 'Beckham Muff'
        context['user_url'] = '/index'

        context['title'] = 'BLOG'
        context['section_heading'] = 'Read our blog'
        context['image_of_post'] = 'img_of_post'
        context['date_created'] = 'July 12, 2018'
        context['created_by'] = 'Admin'
        context['number_of_comments'] = '3'
        context['post_title'] = 'Even the all-powerful Pointing has no control about the blind texts'
        context['post_url'] = 'www.post_url.com'
        context['num_of_posts'] = '6'
        context['pagination'] = '1 to 5'

        


        context['twitter'] = 'twitter.com/ScarletMcLearn'
        context['facebook'] = 'fb.com/ScarletMcLearn'
        context['instagram'] = 'instagram.com/ScarletMcLearn'

        context['footer_heading'] = 'Contact Us'
        context['footer_email'] = 'MailRatulNow@gmail.com'


        context['a_active'] = True

        return context


class BlogSinglePageView(TemplateView):
    template_name = 'portfolio/blog-single.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['message'] = 'Hello world!'

        context['owner_pic'] = owner_pic

        context['bsp_active'] = True

        return context


class BlogPageView(TemplateView):
    template_name = 'portfolio/blog.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['message'] = 'Hello world!'

        context['owner_pic'] = owner_pic

        context['b_active'] = True

        return context


class ContactPageView(TemplateView):
    template_name = 'portfolio/contact.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['message'] = 'Hello world!'

        context['owner_pic'] = owner_pic

        context['user'] = 'Beckham Muff'
        context['user_url'] = '/index'

        context['contact_page_heading'] = 'Contact Information'

        context['address'] = '198 West 21th Street, Suite 721 New York NY 10016'

        context['phone'] = '+ 1235 2355 98'

        context['website'] = 'yoursite.com'

        # form : name , email , message , subject , send message


        context['twitter'] = 'twitter.com/ScarletMcLearn'
        context['facebook'] = 'fb.com/ScarletMcLearn'
        context['instagram'] = 'instagram.com/ScarletMcLearn'

        context['footer_heading'] = 'Contact Us'
        context['footer_email'] = 'MailRatulNow@gmail.com'


        context['c_active'] = True
        return context
        


class IndexPageView(TemplateView):
    template_name = 'portfolio/index.html'

    skill_group = SkillGroup.objects.all()

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['message'] = 'Hello world!'

        context['owner_pic'] = owner_pic

        context['i_active'] = True

        context['pr_active'] = True

        context['skill_group'] = self.skill_group

        return context
        


# class AboutPageView(TemplateView):
#     template_name = 'portfolio/about.html'

#     def get_context_data(self, **kwargs):
#         context = super().get_context_data(**kwargs)
#         context['message'] = 'Hello world!'
#         return context



class PortfolioPageView(TemplateView):
    template_name = 'portfolio/portfolio.html'

    skill_group = SkillGroup.objects.all()

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['message'] = 'Hello world!'

        context['skill_group'] = self.skill_group

        context['owner_pic'] = owner_pic

        context['p_active'] = True

        return context
        


class ServicesPageView(ListView):
    template_name = 'portfolio/services_list.html'

    model = SkillGroup

    context_object_name = 'skill_group'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['message'] = 'Hello world!'

        context['owner_pic'] = owner_pic

        context['s_active'] = True

        return context


class TestView(TemplateView):
    # model = SkillGroup
    # context_object_name = 'skill_group'
    template_name = 'portfolio/test.html'

    skills = Skill.objects.all()

    education = Education.objects.all()

    jobs = Job.objects.all()

    post = get_object_or_404(Post, pk=1)

    # def get(self, request):
    #     form = ContactForm()
    #     return render(request, self.template_name, )

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['skills'] = self.skills

        context['education'] = self.education

        context['jobs'] = self.jobs

        # context['s_active'] = True
        context['form'] = ContactForm()

        context['post'] = self.post

        return context
        




