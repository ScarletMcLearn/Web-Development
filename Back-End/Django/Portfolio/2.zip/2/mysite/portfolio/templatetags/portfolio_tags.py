from django import template

register = template.Library()

@register.simple_tag 
def portfolio_user_name():
    return 'Scarlet McLearn'

@register.simple_tag 
def portfolio_mail():
    return 'MailRatulNow@gmail.com'

@register.simple_tag 
def linkedin_url():
    return 'https://www.linkedin.com/in/SyedElahi/'

@register.simple_tag 
def github_url():
    return 'https://github.com/ScarletMcLearn/'


@register.simple_tag 
def twitter_url():
    return 'https://twitter.com/EssencePrimus'  


@register.simple_tag 
def portfolio_site_url():
    return 'https://twittery.com'  


@register.simple_tag 
def skype_id():
    return 'Ratul_Shams@hotmail.com'


@register.simple_tag 
def contact_number():
    return '00-88-012345678912'


@register.simple_tag 
def address():
    return 'Dhaka, Bangladesh (BD)'


@register.simple_tag 
def my_site_url():
    return 'www.google.com'


@register.simple_tag 
def my_resume_url():
    return 'www.googley.com'


@register.simple_tag 
def my_designation():
    return 'Machine Learning Expert'


@register.simple_tag 
def number_of_clients():
    return '420'

@register.simple_tag 
def number_of_projects():
    return '890'


@register.simple_tag 
def cups_of_coffee():
    return '1000'


@register.simple_tag 
def index_page_bio():
    return 'Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in.'


@register.simple_tag 
def few_lines_about_self():
    return "I'm a UI/UX Designer &amp; Frontend Developer from London, UK. I aim to make a difference through my creative solution."
