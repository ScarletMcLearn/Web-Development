from django.urls import path

from . import views  

urlpatterns = [
    # path('admin/', admin.site.urls),
    path('', views.IndexPageView.as_view()),
    path('index', views.IndexPageView.as_view()),
    path('home', views.HomePage.as_view()),
    path('about', views.AboutPageView.as_view()),
    path('blog', views.BlogPageView.as_view()),
    path('blog-single', views.BlogSinglePageView.as_view()),
    path('contact', views.ContactPageView.as_view()),
    
    path('portfolio', views.PortfolioPageView.as_view()),
    path('services', views.ServicesPageView.as_view()),
    path('test', views.TestView.as_view(), name='test'),

]